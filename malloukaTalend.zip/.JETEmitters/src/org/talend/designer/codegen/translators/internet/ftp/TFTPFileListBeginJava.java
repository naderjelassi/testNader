package org.talend.designer.codegen.translators.internet.ftp;

import org.talend.core.model.process.INode;
import org.talend.core.model.process.ElementParameterParser;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import java.util.List;
import java.util.Map;
import org.talend.core.model.process.IElementParameter;
import org.talend.core.model.utils.NodeUtil;

public class TFTPFileListBeginJava
{
  protected static String nl;
  public static synchronized TFTPFileListBeginJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TFTPFileListBeginJava result = new TFTPFileListBeginJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "\t\t\t\tlog.debug(\"";
  protected final String TEXT_2 = " - Retrieving records from the datasource.\");" + NL + "\t\t\t";
  protected final String TEXT_3 = NL + "\t\t\t\tlog.debug(\"";
  protected final String TEXT_4 = " - Retrieved records count: \"+ nb_line_";
  protected final String TEXT_5 = " + \" .\");" + NL + "\t\t\t";
  protected final String TEXT_6 = " - Retrieved records count: \"+ globalMap.get(\"";
  protected final String TEXT_7 = "_NB_LINE\") + \" .\");" + NL + "\t\t\t";
  protected final String TEXT_8 = " - Written records count: \" + nb_line_";
  protected final String TEXT_9 = NL + "\t\t\t\tfinal StringBuffer log4jSb_";
  protected final String TEXT_10 = " = new StringBuffer();" + NL + "\t\t\t";
  protected final String TEXT_11 = " - Retrieving the record \" + (nb_line_";
  protected final String TEXT_12 = ") + \".\");" + NL + "\t\t\t";
  protected final String TEXT_13 = " - Writing the record \" + nb_line_";
  protected final String TEXT_14 = " + \" to the file.\");" + NL + "\t\t\t";
  protected final String TEXT_15 = " - Processing the record \" + nb_line_";
  protected final String TEXT_16 = " + \".\");" + NL + "\t\t\t";
  protected final String TEXT_17 = " - Processed records count: \" + nb_line_";
  protected final String TEXT_18 = NL + "                log.error(message_";
  protected final String TEXT_19 = ");";
  protected final String TEXT_20 = NL + "                System.err.println(message_";
  protected final String TEXT_21 = NL + " ";
  protected final String TEXT_22 = NL + "  int connectionTimeout_";
  protected final String TEXT_23 = " = Integer.valueOf(";
  protected final String TEXT_24 = NL + "\tjava.util.List<String> maskList_";
  protected final String TEXT_25 = " = new java.util.ArrayList<String>();" + NL;
  protected final String TEXT_26 = NL + "\tmaskList_";
  protected final String TEXT_27 = ".add(\"*\");";
  protected final String TEXT_28 = " " + NL + "\t\tmaskList_";
  protected final String TEXT_29 = ".add(";
  protected final String TEXT_30 = "); ";
  protected final String TEXT_31 = NL + "\tjava.util.Properties props_";
  protected final String TEXT_32 = " = System.getProperties();" + NL + "\tprops_";
  protected final String TEXT_33 = ".put(\"socksProxyPort\", ";
  protected final String TEXT_34 = ");" + NL + "\tprops_";
  protected final String TEXT_35 = ".put(\"socksProxyHost\", ";
  protected final String TEXT_36 = ".put(\"java.net.socks.username\", ";
  protected final String TEXT_37 = ");" + NL + "\t";
  protected final String TEXT_38 = " " + NL + "\tString decryptedProxyPassword_";
  protected final String TEXT_39 = " = routines.system.PasswordEncryptUtil.decryptPassword(";
  protected final String TEXT_40 = NL + " \tString decryptedProxyPassword_";
  protected final String TEXT_41 = " = ";
  protected final String TEXT_42 = "; ";
  protected final String TEXT_43 = NL + NL + "\tprops_";
  protected final String TEXT_44 = ".put(\"java.net.socks.password\", decryptedProxyPassword_";
  protected final String TEXT_45 = ");" + NL + "\tjava.net.Authenticator.setDefault(new java.net.Authenticator() {" + NL + "\t\tpublic java.net.PasswordAuthentication getPasswordAuthentication() {" + NL + "\t\t\treturn new java.net.PasswordAuthentication(";
  protected final String TEXT_46 = ", decryptedProxyPassword_";
  protected final String TEXT_47 = ".toCharArray());" + NL + "\t\t}" + NL + "\t});";
  protected final String TEXT_48 = NL + "\t\tclass MyUserInfo_";
  protected final String TEXT_49 = " implements com.jcraft.jsch.UserInfo, com.jcraft.jsch.UIKeyboardInteractive {" + NL + "\t\t" + NL + "\t\t\t";
  protected final String TEXT_50 = " " + NL + "\t\t\t\tString decryptedPassphrase_";
  protected final String TEXT_51 = ");" + NL + "\t\t\t";
  protected final String TEXT_52 = NL + "\t\t\t\tString decryptedPassphrase_";
  protected final String TEXT_53 = "; " + NL + "\t\t\t";
  protected final String TEXT_54 = NL + "\t\t\t" + NL + "\t\t\tString passphrase_";
  protected final String TEXT_55 = " = decryptedPassphrase_";
  protected final String TEXT_56 = ";" + NL + "" + NL + "\t\t\tpublic String getPassphrase() { return passphrase_";
  protected final String TEXT_57 = "; }" + NL + "" + NL + "\t\t\tpublic boolean promptPassword(String arg0) { return true; } " + NL + "" + NL + "\t\t\tpublic boolean promptPassphrase(String arg0) { return true; } " + NL + "" + NL + "\t\t\tpublic boolean promptYesNo(String arg0) { return true; } " + NL + "" + NL + "\t\t\tpublic void showMessage(String arg0) { }" + NL + "" + NL + "\t\t\tpublic String[] promptKeyboardInteractive(String destination, String name, String instruction, String[] prompt," + NL + "\t\t\t\t\tboolean[] echo) {" + NL + "\t\t\t\t\treturn new String[] {getPassword()};" + NL + "\t\t\t}" + NL + "" + NL + "\t\t\tpublic String getPassword() {" + NL + "\t\t\t\t";
  protected final String TEXT_58 = NL + "\t\t\t\t";
  protected final String TEXT_59 = NL + NL + "\t\t\t\t";
  protected final String TEXT_60 = " " + NL + "\tfinal String decryptedPassword_";
  protected final String TEXT_61 = NL + "\tfinal String decryptedPassword_";
  protected final String TEXT_62 = NL + NL + "\t\t\t\t\t\treturn decryptedPassword_";
  protected final String TEXT_63 = ";" + NL + "\t\t\t\t";
  protected final String TEXT_64 = NL + "\t\t\t\t\t\treturn null;" + NL + "\t\t\t\t";
  protected final String TEXT_65 = NL + "\t\t\t}" + NL + "\t\t}; " + NL + "\t\tfinal com.jcraft.jsch.UserInfo defaultUserInfo_";
  protected final String TEXT_66 = " = new MyUserInfo_";
  protected final String TEXT_67 = "();" + NL + "\t\t" + NL + "\t\t";
  protected final String TEXT_68 = NL + "\t\t" + NL + "\t\t";
  protected final String TEXT_69 = NL + NL + "boolean retry_";
  protected final String TEXT_70 = " = false;" + NL + "int retry_count_";
  protected final String TEXT_71 = " = 0;" + NL + "int retry_max_";
  protected final String TEXT_72 = " = 5;" + NL + "" + NL + "com.jcraft.jsch.Session session_";
  protected final String TEXT_73 = " = null;" + NL + "com.jcraft.jsch.Channel channel_";
  protected final String TEXT_74 = " = null;" + NL + "do {" + NL + "    retry_";
  protected final String TEXT_75 = " = false;" + NL + "" + NL + "    com.jcraft.jsch.JSch jsch_";
  protected final String TEXT_76 = " = new com.jcraft.jsch.JSch(); " + NL;
  protected final String TEXT_77 = NL + "            log.info(\"";
  protected final String TEXT_78 = " - SFTP authentication using a public key.\");" + NL + "            log.debug(\"";
  protected final String TEXT_79 = " - Private key: '\" + ";
  protected final String TEXT_80 = " + \"'.\");";
  protected final String TEXT_81 = NL + "        jsch_";
  protected final String TEXT_82 = ".addIdentity(";
  protected final String TEXT_83 = ", defaultUserInfo_";
  protected final String TEXT_84 = ".getPassphrase());";
  protected final String TEXT_85 = NL + NL + "    session_";
  protected final String TEXT_86 = " = jsch_";
  protected final String TEXT_87 = ".getSession(";
  protected final String TEXT_88 = ", ";
  protected final String TEXT_89 = ");" + NL + "    session_";
  protected final String TEXT_90 = ".setConfig(\"PreferredAuthentications\", \"publickey,password,keyboard-interactive,gssapi-with-mic\");" + NL;
  protected final String TEXT_91 = " - SFTP authentication using a password.\");";
  protected final String TEXT_92 = NL;
  protected final String TEXT_93 = NL + NL + "        session_";
  protected final String TEXT_94 = ".setPassword(decryptedPassword_";
  protected final String TEXT_95 = ".setUserInfo(defaultUserInfo_";
  protected final String TEXT_96 = NL + "        if((\"true\").equals(System.getProperty(\"http.proxySet\"))) {";
  protected final String TEXT_97 = NL + NL + "//check if the host is in the excludes for proxy" + NL + "    boolean isHostIgnored_";
  protected final String TEXT_98 = " = false;" + NL + "    String nonProxyHostsString_";
  protected final String TEXT_99 = " = System.getProperty(\"http.nonProxyHosts\");" + NL + "    String[] nonProxyHosts_";
  protected final String TEXT_100 = " = (nonProxyHostsString_";
  protected final String TEXT_101 = " == null) ? new String[0] : nonProxyHostsString_";
  protected final String TEXT_102 = ".split(\"\\\\|\");" + NL + "    for (String nonProxyHost : nonProxyHosts_";
  protected final String TEXT_103 = ") {" + NL + "        if ((";
  protected final String TEXT_104 = ").matches(nonProxyHost.trim())) {" + NL + "            isHostIgnored_";
  protected final String TEXT_105 = " = true;" + NL + "            break;" + NL + "        }" + NL + "    }" + NL + "            if (!isHostIgnored_";
  protected final String TEXT_106 = ") {" + NL + "                com.jcraft.jsch.ProxyHTTP proxy_";
  protected final String TEXT_107 = " = new com.jcraft.jsch.ProxyHTTP(System.getProperty(\"http.proxyHost\"),Integer.parseInt(System.getProperty(\"http.proxyPort\")));" + NL + "                if(!\"\".equals(System.getProperty(\"http.proxyUser\"))){" + NL + "                    proxy_";
  protected final String TEXT_108 = ".setUserPasswd(System.getProperty(\"http.proxyUser\"),System.getProperty(\"http.proxyPassword\"));" + NL + "                }" + NL + "                session_";
  protected final String TEXT_109 = ".setProxy(proxy_";
  protected final String TEXT_110 = ");" + NL + "            }" + NL + "        } else if (\"local\".equals(System.getProperty(\"http.proxySet\"))) {" + NL + "            String uriString = ";
  protected final String TEXT_111 = " + \":\" + ";
  protected final String TEXT_112 = ";" + NL + "            java.net.Proxy proxyToUse = org.talend.proxy.TalendProxySelector.getInstance().getProxyForUriString(uriString);" + NL + "" + NL + "            if (!proxyToUse.equals(java.net.Proxy.NO_PROXY)) {" + NL + "                java.net.InetSocketAddress proxyAddress = (java.net.InetSocketAddress) proxyToUse.address();" + NL + "                String proxyHost = proxyAddress.getAddress().getHostAddress();" + NL + "                int proxyPort = proxyAddress.getPort();" + NL + "" + NL + "                com.jcraft.jsch.ProxyHTTP proxy_";
  protected final String TEXT_113 = " = new com.jcraft.jsch.ProxyHTTP(proxyHost, proxyPort);" + NL + "" + NL + "                org.talend.proxy.ProxyCreds proxyCreds = org.talend.proxy.TalendProxyAuthenticator.getInstance().getCredsForProxyURI(proxyHost + \":\" + proxyPort);" + NL + "                if (proxyCreds != null) {" + NL + "                    proxy_";
  protected final String TEXT_114 = ".setUserPasswd(proxyCreds.getUser(), proxyCreds.getPass());" + NL + "                }" + NL + "" + NL + "                session_";
  protected final String TEXT_115 = ");" + NL + "            }" + NL + "        }";
  protected final String TEXT_116 = NL + "        log.info(\"";
  protected final String TEXT_117 = " - Attempt to connect to  '\" + ";
  protected final String TEXT_118 = " + \"' with username '\" + ";
  protected final String TEXT_119 = NL + NL + "    channel_";
  protected final String TEXT_120 = " = null;" + NL + "    try {" + NL + "        if (connectionTimeout_";
  protected final String TEXT_121 = " > 0) {" + NL + "            session_";
  protected final String TEXT_122 = ".connect(connectionTimeout_";
  protected final String TEXT_123 = ");" + NL + "        } else {" + NL + "            session_";
  protected final String TEXT_124 = ".connect();" + NL + "        }" + NL + "        channel_";
  protected final String TEXT_125 = " = session_";
  protected final String TEXT_126 = ".openChannel(\"sftp\");" + NL + "        if (connectionTimeout_";
  protected final String TEXT_127 = " > 0) {" + NL + "            channel_";
  protected final String TEXT_128 = ");" + NL + "        } else {" + NL + "            channel_";
  protected final String TEXT_129 = ".connect();" + NL + "        }";
  protected final String TEXT_130 = " - Connect to '\" + ";
  protected final String TEXT_131 = " + \"' has succeeded.\");";
  protected final String TEXT_132 = NL + "    } catch (com.jcraft.jsch.JSchException e_";
  protected final String TEXT_133 = ") {" + NL + "        try {" + NL + "            if(channel_";
  protected final String TEXT_134 = "!=null) {" + NL + "                channel_";
  protected final String TEXT_135 = ".disconnect();" + NL + "            }" + NL + "" + NL + "            if(session_";
  protected final String TEXT_136 = "!=null) {" + NL + "                session_";
  protected final String TEXT_137 = ".disconnect();" + NL + "            }" + NL + "        } catch(java.lang.Exception ce_";
  protected final String TEXT_138 = ") {";
  protected final String TEXT_139 = NL + "                log.warn(\"";
  protected final String TEXT_140 = " - close sftp connection failed : \" + ce_";
  protected final String TEXT_141 = ".getClass() + \" : \" + ce_";
  protected final String TEXT_142 = ".getMessage());";
  protected final String TEXT_143 = NL + "        }" + NL + "" + NL + "        String message_";
  protected final String TEXT_144 = " = new TalendException(null, null, null).getExceptionCauseMessage(e_";
  protected final String TEXT_145 = ");" + NL + "        if(message_";
  protected final String TEXT_146 = ".contains(\"Signature length not correct\") || message_";
  protected final String TEXT_147 = ".contains(\"connection is closed by foreign host\")) {" + NL + "            retry_";
  protected final String TEXT_148 = " = true;" + NL + "            retry_count_";
  protected final String TEXT_149 = "++;";
  protected final String TEXT_150 = " - connect: Signature length not correct or connection is closed by foreign host, so retry, retry time : \" + retry_count_";
  protected final String TEXT_151 = NL + "        } else {" + NL + "            throw e_";
  protected final String TEXT_152 = ";" + NL + "        }" + NL + "    }" + NL + "} while(retry_";
  protected final String TEXT_153 = " && (retry_count_";
  protected final String TEXT_154 = " < retry_max_";
  protected final String TEXT_155 = "));" + NL + "" + NL + "com.jcraft.jsch.ChannelSftp c_";
  protected final String TEXT_156 = " = (com.jcraft.jsch.ChannelSftp)channel_";
  protected final String TEXT_157 = ";" + NL + "\t\t" + NL + "\t\t";
  protected final String TEXT_158 = NL + "\t\t\tc_";
  protected final String TEXT_159 = ".setFilenameEncoding(";
  protected final String TEXT_160 = ");" + NL + "\t\t";
  protected final String TEXT_161 = "\t" + NL + "\t\tcom.jcraft.jsch.ChannelSftp c_";
  protected final String TEXT_162 = " = (com.jcraft.jsch.ChannelSftp)globalMap.get(\"";
  protected final String TEXT_163 = "\");" + NL + "\t\t";
  protected final String TEXT_164 = NL + "\t\t\tif(c_";
  protected final String TEXT_165 = "!=null && c_";
  protected final String TEXT_166 = ".getSession()!=null) {" + NL + "\t\t\t\tlog.info(\"";
  protected final String TEXT_167 = " - Use an existing connection. Connection username: \" + c_";
  protected final String TEXT_168 = ".getSession().getUserName() + \", Connection hostname: \" + c_";
  protected final String TEXT_169 = ".getSession().getHost() + \", Connection port: \" + c_";
  protected final String TEXT_170 = ".getSession().getPort() + \".\"); " + NL + "\t\t\t}" + NL + "\t\t";
  protected final String TEXT_171 = NL + "\t\tif(c_";
  protected final String TEXT_172 = ".getHome()!=null && !c_";
  protected final String TEXT_173 = ".getHome().equals(c_";
  protected final String TEXT_174 = ".pwd())){" + NL + "\t  \t\tc_";
  protected final String TEXT_175 = ".cd(c_";
  protected final String TEXT_176 = ".getHome());" + NL + "\t  \t}";
  protected final String TEXT_177 = NL + "\tString remotedir_";
  protected final String TEXT_178 = ".replaceAll(\"\\\\\\\\\", \"/\");" + NL + "\tjava.util.Vector<com.jcraft.jsch.ChannelSftp.LsEntry> vector_";
  protected final String TEXT_179 = " = c_";
  protected final String TEXT_180 = ".ls(remotedir_";
  protected final String TEXT_181 = ");" + NL + "\tcom.jcraft.jsch.ChannelSftp.LsEntry[] sftpFiles_";
  protected final String TEXT_182 = " = vector_";
  protected final String TEXT_183 = ".toArray(new com.jcraft.jsch.ChannelSftp.LsEntry[0]);" + NL + "\tint nb_file_";
  protected final String TEXT_184 = " = 0;  " + NL + "\tList<String> fileListTemp_";
  protected final String TEXT_185 = " = new java.util.ArrayList<String>();";
  protected final String TEXT_186 = NL + "\t\tList<String> fullFileInfoList_";
  protected final String TEXT_187 = NL + NL + "\tfor (String filemask_";
  protected final String TEXT_188 = " : maskList_";
  protected final String TEXT_189 = ") {" + NL + "\t\tjava.util.regex.Pattern fileNamePattern_";
  protected final String TEXT_190 = " = java.util.regex.Pattern.compile(filemask_";
  protected final String TEXT_191 = ".replaceAll(\"\\\\.\", \"\\\\\\\\.\").replaceAll(\"\\\\*\", \".*\"));" + NL + "\t" + NL + "\t\tfor (com.jcraft.jsch.ChannelSftp.LsEntry filemaskTemp_";
  protected final String TEXT_192 = " : sftpFiles_";
  protected final String TEXT_193 = ") {" + NL + "\t\t\tString fileName_";
  protected final String TEXT_194 = " = filemaskTemp_";
  protected final String TEXT_195 = ".getFilename();" + NL + "\t\t\tif ((\".\").equals(fileName_";
  protected final String TEXT_196 = ") || (\"..\").equals(fileName_";
  protected final String TEXT_197 = ")) {" + NL + "\t\t\t\tcontinue;" + NL + "\t\t\t}" + NL + "\t\t\tif (fileNamePattern_";
  protected final String TEXT_198 = ".matcher(fileName_";
  protected final String TEXT_199 = ").matches()) {";
  protected final String TEXT_200 = NL + "\t\t\t\t\tfullFileInfoList_";
  protected final String TEXT_201 = ".add(filemaskTemp_";
  protected final String TEXT_202 = ".getLongname());";
  protected final String TEXT_203 = NL + "\t\t\t\tfileListTemp_";
  protected final String TEXT_204 = ".add(fileName_";
  protected final String TEXT_205 = ");" + NL + "\t\t\t}" + NL + "\t\t}" + NL + "\t}" + NL + "" + NL + "\t";
  protected final String TEXT_206 = NL + "\t\tlog.info(\"";
  protected final String TEXT_207 = " - Listing files from server.\");" + NL + "\t";
  protected final String TEXT_208 = NL + "\tfor (int counter_";
  protected final String TEXT_209 = " = 0; counter_";
  protected final String TEXT_210 = " < fileListTemp_";
  protected final String TEXT_211 = ".size(); counter_";
  protected final String TEXT_212 = "++) {" + NL + "\t\tString currentFileName_";
  protected final String TEXT_213 = " = fileListTemp_";
  protected final String TEXT_214 = ".get(counter_";
  protected final String TEXT_215 = ");" + NL + "\t\tString currentFilePath_";
  protected final String TEXT_216 = " = remotedir_";
  protected final String TEXT_217 = ";" + NL + "\t\tif(!remotedir_";
  protected final String TEXT_218 = ".endsWith(\"/\")&&!remotedir_";
  protected final String TEXT_219 = ".endsWith(\"\\\\\")){" + NL + "\t\t\tcurrentFilePath_";
  protected final String TEXT_220 = " += \"/\";" + NL + "\t\t}" + NL + "\t\tcurrentFilePath_";
  protected final String TEXT_221 = " += currentFileName_";
  protected final String TEXT_222 = ";" + NL + "\t\t";
  protected final String TEXT_223 = NL + "\t\t\tlog.debug(\"";
  protected final String TEXT_224 = " - List file : '\" + currentFilePath_";
  protected final String TEXT_225 = " + \"' .\");" + NL + "\t\t";
  protected final String TEXT_226 = NL + "\t\t\tglobalMap.put(\"";
  protected final String TEXT_227 = "_CURRENT_FILE\", fullFileInfoList_";
  protected final String TEXT_228 = "));";
  protected final String TEXT_229 = "_CURRENT_FILE\", currentFileName_";
  protected final String TEXT_230 = NL + "\t\tglobalMap.put(\"";
  protected final String TEXT_231 = "_CURRENT_FILEPATH\", currentFilePath_";
  protected final String TEXT_232 = ");" + NL + "\t\tnb_file_";
  protected final String TEXT_233 = NL + "        org.apache.commons.net.ftp.FTPSClient ftp_";
  protected final String TEXT_234 = " = null;";
  protected final String TEXT_235 = NL + NL + "\tclass MyTrust_";
  protected final String TEXT_236 = " {" + NL + "" + NL + "\t\tprivate javax.net.ssl.TrustManager[] getTrustManagers() " + NL + "\t\tthrows java.security.KeyStoreException, java.security.NoSuchAlgorithmException, " + NL + "\t\t\tjava.security.cert.CertificateException, java.security.UnrecoverableKeyException," + NL + "\t\t\tjava.io.IOException {" + NL + "\t\t\tjava.security.KeyStore ks = java.security.KeyStore.getInstance(\"JKS\");" + NL;
  protected final String TEXT_237 = " " + NL + "\t\t\t\tString decryptedKeyStorePassword_";
  protected final String TEXT_238 = NL + "\t\t\t\tString decryptedKeyStorePassword_";
  protected final String TEXT_239 = NL + "\t\t\tks.load(new java.io.FileInputStream(";
  protected final String TEXT_240 = "), decryptedKeyStorePassword_";
  protected final String TEXT_241 = ".toCharArray());" + NL + "\t\t\tjavax.net.ssl.TrustManagerFactory tmf = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());" + NL + "\t\t\ttmf.init(ks);" + NL + "\t\t\treturn tmf.getTrustManagers();" + NL + "\t\t}" + NL + "\t}" + NL + "    javax.net.ssl.SSLContext sslContext_";
  protected final String TEXT_242 = " = null;" + NL + "    javax.net.ssl.TrustManager[] trustManager_";
  protected final String TEXT_243 = " = null;" + NL + "    javax.net.ssl.SSLSocketFactory sslSocketFactory_";
  protected final String TEXT_244 = " = null;" + NL + "    MyTrust_";
  protected final String TEXT_245 = " myTrust_";
  protected final String TEXT_246 = " = null;" + NL;
  protected final String TEXT_247 = NL + "\tclass PrivateKeyManager_";
  protected final String TEXT_248 = " {" + NL + "\t\tprivate javax.net.ssl.KeyManager[] getKeyManagers()" + NL + "            throws java.security.KeyStoreException, java.security.NoSuchAlgorithmException," + NL + "                java.security.cert.CertificateException, java.security.UnrecoverableKeyException," + NL + "                java.io.IOException {" + NL + "            java.security.KeyStore ks = java.security.KeyStore.getInstance(\"JKS\");";
  protected final String TEXT_249 = " " + NL + "\t\t\t\tString decryptedKeyStorePassword = routines.system.PasswordEncryptUtil.decryptPassword(";
  protected final String TEXT_250 = NL + "\t\t\t\tString decryptedKeyStorePassword = ";
  protected final String TEXT_251 = ";";
  protected final String TEXT_252 = "), decryptedKeyStorePassword.toCharArray());" + NL + "\t\t\tjavax.net.ssl.KeyManagerFactory kmf = javax.net.ssl.KeyManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());" + NL + "\t\t\tkmf.init(ks, decryptedKeyStorePassword.toCharArray());" + NL + "\t\t\treturn kmf.getKeyManagers();" + NL + "\t\t}" + NL + "\t}" + NL + "" + NL + "    try {" + NL + "        sslContext_";
  protected final String TEXT_253 = " = javax.net.ssl.SSLContext.getInstance(\"SSL\");" + NL + "        myTrust_";
  protected final String TEXT_254 = " = new MyTrust_";
  protected final String TEXT_255 = "();" + NL + "        trustManager_";
  protected final String TEXT_256 = " = myTrust_";
  protected final String TEXT_257 = ".getTrustManagers();" + NL + "" + NL + "        PrivateKeyManager_";
  protected final String TEXT_258 = " privateKeyManager_";
  protected final String TEXT_259 = " = new PrivateKeyManager_";
  protected final String TEXT_260 = "();" + NL + "        javax.net.ssl.KeyManager[] keyManager_";
  protected final String TEXT_261 = " = privateKeyManager_";
  protected final String TEXT_262 = ".getKeyManagers();" + NL + "" + NL + "        sslContext_";
  protected final String TEXT_263 = ".init(keyManager_";
  protected final String TEXT_264 = ", trustManager_";
  protected final String TEXT_265 = ", new java.security.SecureRandom());" + NL + "        sslSocketFactory_";
  protected final String TEXT_266 = " = sslContext_";
  protected final String TEXT_267 = ".getSocketFactory();" + NL + "" + NL + "        if((\"true\").equals(System.getProperty(\"http.proxySet\")) ){";
  protected final String TEXT_268 = ") {" + NL + "                String httpProxyHost = System.getProperty(\"http.proxyHost\");" + NL + "                int httpProxyPort = Integer.getInteger(\"http.proxyPort\");" + NL + "                String httpProxyUser = System.getProperty(\"http.proxyUser\");" + NL + "                String httpProxyPass = System.getProperty(\"http.proxyPassword\");" + NL + "                ftp_";
  protected final String TEXT_269 = " = new org.talend.ftp.HTTPProxyFTPSClient(";
  protected final String TEXT_270 = ", sslContext_";
  protected final String TEXT_271 = ", httpProxyHost, httpProxyPort, httpProxyUser, httpProxyPass);" + NL + "            } else {" + NL + "                ftp_";
  protected final String TEXT_272 = " = new org.talend.ftp.SSLSessionReuseFTPSClient(";
  protected final String TEXT_273 = ";" + NL + "            java.net.Proxy proxyToUse = org.talend.proxy.TalendProxySelector.getInstance().getProxyForUriString(uriString);" + NL + "" + NL + "            if (!proxyToUse.equals(java.net.Proxy.NO_PROXY)) {" + NL + "                java.net.InetSocketAddress proxyAddress = (java.net.InetSocketAddress) proxyToUse.address();" + NL + "" + NL + "                String httpProxyHost = proxyAddress.getAddress().getHostAddress();" + NL + "                int httpProxyPort = proxyAddress.getPort();" + NL + "                String httpProxyUser = \"\";" + NL + "                String httpProxyPass = \"\"; //leave it empty if proxy creds weren't specified" + NL + "" + NL + "                org.talend.proxy.ProxyCreds proxyCreds = org.talend.proxy.TalendProxyAuthenticator.getInstance().getCredsForProxyURI(httpProxyHost + \":\" + httpProxyPort);" + NL + "                if (proxyCreds != null) {" + NL + "                    httpProxyUser = proxyCreds.getUser();" + NL + "                    httpProxyPass = proxyCreds.getPass();" + NL + "                }" + NL + "" + NL + "                ftp_";
  protected final String TEXT_274 = ", httpProxyHost, httpProxyPort, httpProxyUser, httpProxyPass);" + NL + "" + NL + "            } else { //no http proxy for ftp host defined" + NL + "                ftp_";
  protected final String TEXT_275 = ");" + NL + "            }" + NL + "        } else {" + NL + "            ftp_";
  protected final String TEXT_276 = ");" + NL + "        }" + NL;
  protected final String TEXT_277 = " -FTPS security Mode is ";
  protected final String TEXT_278 = ".\");";
  protected final String TEXT_279 = NL + "        ftp_";
  protected final String TEXT_280 = ".setControlEncoding(";
  protected final String TEXT_281 = ");" + NL;
  protected final String TEXT_282 = " - Attempt to connect to '\" + ";
  protected final String TEXT_283 = "+ \"'.\");";
  protected final String TEXT_284 = NL + NL + "        if (connectionTimeout_";
  protected final String TEXT_285 = " > 0) {" + NL + "            ftp_";
  protected final String TEXT_286 = ".setDefaultTimeout(connectionTimeout_";
  protected final String TEXT_287 = ");" + NL + "        }" + NL + "" + NL + "        ftp_";
  protected final String TEXT_288 = ".setStrictReplyParsing(";
  protected final String TEXT_289 = ");" + NL + "        ftp_";
  protected final String TEXT_290 = ".connect(";
  protected final String TEXT_291 = ",";
  protected final String TEXT_292 = NL + NL + "        boolean isLoginSuccessful_";
  protected final String TEXT_293 = " = ftp_";
  protected final String TEXT_294 = ".login(";
  protected final String TEXT_295 = ", decryptedPassword_";
  protected final String TEXT_296 = ");" + NL + "" + NL + "        if (!isLoginSuccessful_";
  protected final String TEXT_297 = ") {" + NL + "            throw new RuntimeException(\"Login failed\");" + NL + "        }" + NL + "" + NL + "        ftp_";
  protected final String TEXT_298 = ".setFileType(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE);" + NL + "        ftp_";
  protected final String TEXT_299 = ".setRemoteVerificationEnabled(";
  protected final String TEXT_300 = NL + "            ftp_";
  protected final String TEXT_301 = ".execPBSZ(";
  protected final String TEXT_302 = ".execPROT(";
  protected final String TEXT_303 = NL + "    } catch (Exception e) {";
  protected final String TEXT_304 = NL + "            log.error(\"";
  protected final String TEXT_305 = " - Can't create connection: \" + e.getMessage());";
  protected final String TEXT_306 = NL + "        throw e;" + NL + "    }" + NL;
  protected final String TEXT_307 = ".enterLocalPassiveMode();";
  protected final String TEXT_308 = NL + "            log.debug(\"";
  protected final String TEXT_309 = " - Using the passive mode.\");";
  protected final String TEXT_310 = " = (org.apache.commons.net.ftp.FTPSClient) globalMap.get(\"";
  protected final String TEXT_311 = "\");";
  protected final String TEXT_312 = NL + "        org.apache.commons.net.ftp.FTPClient ftp_";
  protected final String TEXT_313 = " = (org.apache.commons.net.ftp.FTPClient) globalMap.get(\"";
  protected final String TEXT_314 = NL + "                if(ftp_";
  protected final String TEXT_315 = "!=null) {" + NL + "                    log.info(\"";
  protected final String TEXT_316 = " - Use an existing connection. Connection hostname: \" +  ftp_";
  protected final String TEXT_317 = ".getRemoteAddress().toString() + \", Connection port: \" + ftp_";
  protected final String TEXT_318 = ".getRemotePort() + \".\");" + NL + "                }";
  protected final String TEXT_319 = NL + "    try {" + NL + "    if((\"true\").equals(System.getProperty(\"http.proxySet\")) ){";
  protected final String TEXT_320 = " = true;" + NL + "            break;" + NL + "        }" + NL + "    }" + NL + "        if (!isHostIgnored_";
  protected final String TEXT_321 = ") {" + NL + "            String httpProxyHost = System.getProperty(\"http.proxyHost\");" + NL + "            int httpProxyPort = Integer.getInteger(\"http.proxyPort\");" + NL + "            String httpProxyUser = System.getProperty(\"http.proxyUser\");" + NL + "            String httpProxyPass = System.getProperty(\"http.proxyPassword\");" + NL + "            ftp_";
  protected final String TEXT_322 = " = new org.apache.commons.net.ftp.FTPHTTPClient(httpProxyHost, httpProxyPort, httpProxyUser, httpProxyPass);" + NL + "        } else {" + NL + "            ftp_";
  protected final String TEXT_323 = " = new org.apache.commons.net.ftp.FTPClient();" + NL + "        }" + NL + "    } else if (\"local\".equals(System.getProperty(\"http.proxySet\"))) {" + NL + "        String uriString = ";
  protected final String TEXT_324 = ";" + NL + "        java.net.Proxy proxyToUse = org.talend.proxy.TalendProxySelector.getInstance().getProxyForUriString(uriString);" + NL + "" + NL + "        if (!proxyToUse.equals(java.net.Proxy.NO_PROXY)) {" + NL + "            java.net.InetSocketAddress proxyAddress = (java.net.InetSocketAddress) proxyToUse.address();" + NL + "" + NL + "            String httpProxyHost = proxyAddress.getAddress().getHostAddress();" + NL + "            int httpProxyPort = proxyAddress.getPort();" + NL + "            String httpProxyUser = \"\";" + NL + "            String httpProxyPass = \"\"; //leave it empty if proxy creds weren't specified" + NL + "" + NL + "            org.talend.proxy.ProxyCreds proxyCreds = org.talend.proxy.TalendProxyAuthenticator.getInstance().getCredsForProxyURI(httpProxyHost + \":\" + httpProxyPort);" + NL + "            if (proxyCreds != null) {" + NL + "                httpProxyUser = proxyCreds.getUser();" + NL + "                    httpProxyPass = proxyCreds.getPass();" + NL + "            }" + NL + "" + NL + "            ftp_";
  protected final String TEXT_325 = " = new org.apache.commons.net.ftp.FTPHTTPClient(httpProxyHost, httpProxyPort, httpProxyUser, httpProxyPass);" + NL + "" + NL + "        } else { //no http proxy for ftp host defined" + NL + "            ftp_";
  protected final String TEXT_326 = " = new org.apache.commons.net.ftp.FTPClient();" + NL + "        }" + NL + "    } else {" + NL + "        ftp_";
  protected final String TEXT_327 = " = new org.apache.commons.net.ftp.FTPClient();" + NL + "    }" + NL + "    ";
  protected final String TEXT_328 = ".setFileType(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE);" + NL + "    } catch (Exception e) {";
  protected final String TEXT_329 = " " + NL + "    int nb_file_";
  protected final String TEXT_330 = " = 0;" + NL + "    org.apache.commons.net.ftp.FTPFile[] ftpFiles_";
  protected final String TEXT_331 = " = null;" + NL + "    String rootDir_";
  protected final String TEXT_332 = ".printWorkingDirectory();" + NL + "    List<org.apache.commons.net.ftp.FTPFile> fileListTemp_";
  protected final String TEXT_333 = " = new java.util.ArrayList<>();" + NL;
  protected final String TEXT_334 = NL + "    String remotedir_";
  protected final String TEXT_335 = " = (";
  protected final String TEXT_336 = ").replaceAll(\"\\\\\\\\\",\"/\");" + NL + "    boolean cwdSuccess_";
  protected final String TEXT_337 = ".changeWorkingDirectory(remotedir_";
  protected final String TEXT_338 = ");" + NL + "" + NL + "    if (!cwdSuccess_";
  protected final String TEXT_339 = ") {" + NL + "        throw new RuntimeException(\"Failed to change remote directory. \" + ftp_";
  protected final String TEXT_340 = ".getReplyString());" + NL + "    }" + NL + "" + NL + "    ftpFiles_";
  protected final String TEXT_341 = ".listFiles();" + NL + "\t";
  protected final String TEXT_342 = NL + "\tString[] nameLists_";
  protected final String TEXT_343 = ".listNames();" + NL + "\tList<String> nameListsTemp_";
  protected final String TEXT_344 = " = new java.util.ArrayList<>();" + NL + "\t";
  protected final String TEXT_345 = NL + "\t" + NL + NL;
  protected final String TEXT_346 = NL + "    ftp_";
  protected final String TEXT_347 = ".changeWorkingDirectory(rootDir_";
  protected final String TEXT_348 = NL + "    for (String filemask_";
  protected final String TEXT_349 = ") {" + NL + "        java.util.regex.Pattern fileNamePattern_";
  protected final String TEXT_350 = ".replaceAll(\"\\\\.\", \"\\\\\\\\.\").replaceAll(\"\\\\*\", \".*\"));" + NL + "\t";
  protected final String TEXT_351 = NL + "        if(nameLists_";
  protected final String TEXT_352 = " != null){" + NL + "            for (String ftpFile_";
  protected final String TEXT_353 = " : nameLists_";
  protected final String TEXT_354 = ") {" + NL + "                if (fileNamePattern_";
  protected final String TEXT_355 = ".matcher(ftpFile_";
  protected final String TEXT_356 = ").matches()) {" + NL + "                    nameListsTemp_";
  protected final String TEXT_357 = ".add(ftpFile_";
  protected final String TEXT_358 = ");" + NL + "                }" + NL + "            }" + NL + "        }";
  protected final String TEXT_359 = NL + "        for (org.apache.commons.net.ftp.FTPFile ftpFile_";
  protected final String TEXT_360 = " : ftpFiles_";
  protected final String TEXT_361 = ") {" + NL + "\t\tString ftpFileName_";
  protected final String TEXT_362 = " = ftpFile_";
  protected final String TEXT_363 = ".getName();" + NL + "            if (ftpFileName_";
  protected final String TEXT_364 = "!=null && fileNamePattern_";
  protected final String TEXT_365 = ".matcher(ftpFileName_";
  protected final String TEXT_366 = ").matches()) {" + NL + "                fileListTemp_";
  protected final String TEXT_367 = ");" + NL + "            }" + NL + "        }" + NL + "\t\t";
  protected final String TEXT_368 = NL + "    }" + NL + "" + NL + "    String currentFilePath_";
  protected final String TEXT_369 = ";" + NL + "    if(!remotedir_";
  protected final String TEXT_370 = ".endsWith(\"\\\\\")){" + NL + "        currentFilePath_";
  protected final String TEXT_371 = " += \"/\";" + NL + "    }";
  protected final String TEXT_372 = NL + "    for (String ftpFile_";
  protected final String TEXT_373 = " : nameListsTemp_";
  protected final String TEXT_374 = ") {" + NL + "        String currentFileName_";
  protected final String TEXT_375 = ";" + NL;
  protected final String TEXT_376 = NL + NL + "    for (org.apache.commons.net.ftp.FTPFile ftpFile_";
  protected final String TEXT_377 = " : fileListTemp_";
  protected final String TEXT_378 = " = null;" + NL + "            currentFileName_";
  protected final String TEXT_379 = ".toString();";
  protected final String TEXT_380 = " + \"' .\");";
  protected final String TEXT_381 = " ";
  protected final String TEXT_382 = NL + "        globalMap.put(\"";
  protected final String TEXT_383 = " + currentFileName_";
  protected final String TEXT_384 = " + ftpFile_";
  protected final String TEXT_385 = ".getName());" + NL + "\t\t";
  protected final String TEXT_386 = NL + "        nb_file_";
  protected final String TEXT_387 = "++;" + NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
	//this util class use by set log4j debug paramters
	class DefaultLog4jFileUtil {
	
		INode node = null;
	    String cid = null;
 		boolean isLog4jEnabled = false;
 		String label = null;
 		
 		public DefaultLog4jFileUtil(){
 		}
 		public DefaultLog4jFileUtil(INode node) {
 			this.node = node;
 			this.cid = node.getUniqueName();
 			this.label = cid;
			this.isLog4jEnabled = ("true").equals(org.talend.core.model.process.ElementParameterParser.getValue(node.getProcess(), "__LOG4J_ACTIVATE__"));
 		}
 		
 		public void setCid(String cid) {
 			this.cid = cid;
 		}
 		
		//for all tFileinput* components 
		public void startRetriveDataInfo() {
			if (isLog4jEnabled) {
			
    stringBuffer.append(TEXT_1);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_2);
    
			}
		}
		
		public void retrievedDataNumberInfo() {
			if (isLog4jEnabled) {
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_5);
    
			}
		}
		
		public void retrievedDataNumberInfoFromGlobalMap(INode node) {
			if (isLog4jEnabled) {
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_7);
    
			}
		}
		
		//for all tFileinput* components 
		public void retrievedDataNumberInfo(INode node) {
			if (isLog4jEnabled) {
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_5);
    
			}
		}
		
		public void writeDataFinishInfo(INode node) {
			if(isLog4jEnabled){
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_5);
    
			}
		}
		
 		//TODO delete it and remove all log4jSb parameter from components
		public void componentStartInfo(INode node) {
			if (isLog4jEnabled) {
			
    stringBuffer.append(TEXT_9);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_10);
    
			}
		}
		
		//TODO rename or delete it
		public void debugRetriveData(INode node,boolean hasIncreased) {
			if(isLog4jEnabled){
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(cid);
    stringBuffer.append(hasIncreased?"":"+1");
    stringBuffer.append(TEXT_12);
    
			}
		}
		
		//TODO rename or delete it
		public void debugRetriveData(INode node) {
			debugRetriveData(node,true);
		}
		
		//TODO rename or delete it
		public void debugWriteData(INode node) {
			if(isLog4jEnabled){
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_13);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_14);
    
			}
		}
		
		public void logCurrentRowNumberInfo() {
			if(isLog4jEnabled){
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_15);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_16);
    
			}
		}
		
		public void logDataCountInfo() {
			if(isLog4jEnabled){
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_5);
    
			}
		}

        public void logErrorMessage() {
            if(isLog4jEnabled){
            
    stringBuffer.append(TEXT_18);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    
            } else {
            
    stringBuffer.append(TEXT_20);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    
            }
        }
	}
	
	final DefaultLog4jFileUtil log4jFileUtil = new DefaultLog4jFileUtil((INode)(((org.talend.designer.codegen.config.CodeGeneratorArgument)argument).getArgument()));
	
    stringBuffer.append(TEXT_21);
    
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();  
String host = ElementParameterParser.getValue(node, "__HOST__");
String port = ElementParameterParser.getValue(node, "__PORT__");
String ftpsPort = ElementParameterParser.getValue(node, "__FTPS_PORT__");
String user = ElementParameterParser.getValue(node, "__USERNAME__");

boolean use_encoding = "true".equals(ElementParameterParser.getValue(node, "__USE_ENCODING__"));

String remotedir = ElementParameterParser.getValue(node, "__REMOTEDIR__");
boolean dirFull = ("true").equals(ElementParameterParser.getValue(node, "__DIR_FULL__"));
String cid = node.getUniqueName();
String encoding = ElementParameterParser.getValue(node, "__ENCODING__");
String authMethod = ElementParameterParser.getValue(node, "__AUTH_METHOD__");
String privateKey = ElementParameterParser.getValue(node, "__PRIVATEKEY__");

boolean useProxy = ("true").equals(ElementParameterParser.getValue(node, "__USE_PROXY__"));
String proxyHost = ElementParameterParser.getValue(node, "__PROXY_HOST__");
String proxyPort = ElementParameterParser.getValue(node, "__PROXY_PORT__");
String proxyUser = ElementParameterParser.getValue(node, "__PROXY_USERNAME__");

String connectMode = ElementParameterParser.getValue(node, "__CONNECT_MODE__");  
List<Map<String, String>> files = (List<Map<String,String>>)ElementParameterParser.getObjectValue(node, "__FILES__");
String connection = ElementParameterParser.getValue(node, "__CONNECTION__");
String conn= "conn_" + connection;
String useExistingConn = ElementParameterParser.getValue(node, "__USE_EXISTING_CONNECTION__");
boolean moveToCurrentDir = ("true").equals(ElementParameterParser.getValue(node, "__MOVE_TO_THE_CURRENT_DIRECTORY__"));
boolean sftp = false;
boolean ftps = false;
String protectionLevel = ElementParameterParser.getValue(node, "__FTPS_PROT__");
String protectionBufferSize = ElementParameterParser.getValue(node, "__FTPS_PROTECTION_BUFF_SIZE__");
String timeoutValue = ElementParameterParser.getValue(node, "__CONNECTION_TIMEOUT__");
boolean useRemoteVerification = ("true").equals(ElementParameterParser.getValue(node, "__REMOTE_VERIFICATION__"));
boolean useStrictReplyParsing = ("true").equals(ElementParameterParser.getValue(node, "__USE_STRICT_REPLY_PARSING__"));

if (("true").equals(useExistingConn)) {
  List< ? extends INode> nodeList = node.getProcess().getGeneratingNodes();

  for (INode n : nodeList) {
	if (n.getUniqueName().equals(connection)) {
	  sftp = ("true").equals(ElementParameterParser.getValue(n, "__SFTP__"));
	  ftps = ("true").equals(ElementParameterParser.getValue(n, "__FTPS__"));
	}
  }
} else {
  sftp = ("true").equals(ElementParameterParser.getValue(node, "__SFTP__"));
  ftps = ("true").equals(ElementParameterParser.getValue(node, "__FTPS__"));

    stringBuffer.append(TEXT_22);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_23);
    stringBuffer.append(timeoutValue );
    stringBuffer.append(TEXT_19);
    
}
boolean isLog4jEnabled = ("true").equals(ElementParameterParser.getValue(node.getProcess(), "__LOG4J_ACTIVATE__"));
String passwordFieldName = "";


    stringBuffer.append(TEXT_24);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_25);
    
if (files.size() == 0) {

    stringBuffer.append(TEXT_26);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_27);
    
} else {
  for (int i = 0; i < files.size(); i++) {
	Map<String, String> line = files.get(i);
	
    stringBuffer.append(TEXT_28);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_29);
    stringBuffer.append( line.get("FILEMASK") );
    stringBuffer.append(TEXT_30);
    
  }
}

//The following part support the socks proxy for FTP, FTPS and SFTP (Socks V4 or V5, they are all OK). 
//And it can not work with the FTP proxy directly, only support the socks proxy.
if (useProxy && !("true").equals(useExistingConn)) {

    stringBuffer.append(TEXT_31);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_32);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_33);
    stringBuffer.append(proxyPort );
    stringBuffer.append(TEXT_34);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_35);
    stringBuffer.append(proxyHost );
    stringBuffer.append(TEXT_34);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_36);
    stringBuffer.append(proxyUser );
    stringBuffer.append(TEXT_37);
    
passwordFieldName = "__PROXY_PASSWORD__";
if (ElementParameterParser.canEncrypt(node, passwordFieldName)) {

    stringBuffer.append(TEXT_38);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_39);
    stringBuffer.append(ElementParameterParser.getEncryptedValue(node, passwordFieldName));
    stringBuffer.append(TEXT_19);
    } else {
    stringBuffer.append(TEXT_40);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_41);
    stringBuffer.append( ElementParameterParser.getValue(node, passwordFieldName));
    stringBuffer.append(TEXT_42);
    }
    stringBuffer.append(TEXT_43);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_44);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_45);
    stringBuffer.append(proxyUser );
    stringBuffer.append(TEXT_46);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_47);
    
}

if (sftp) {// *** sftp *** //

	if (("false").equals(useExistingConn)) {
	
    stringBuffer.append(TEXT_48);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_49);
    
			passwordFieldName = "__PASSPHRASE__";
			if (ElementParameterParser.canEncrypt(node, passwordFieldName)) {
			
    stringBuffer.append(TEXT_50);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_39);
    stringBuffer.append(ElementParameterParser.getEncryptedValue(node, passwordFieldName));
    stringBuffer.append(TEXT_51);
    } else {
    stringBuffer.append(TEXT_52);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_41);
    stringBuffer.append( ElementParameterParser.getValue(node, passwordFieldName));
    stringBuffer.append(TEXT_53);
    }
    stringBuffer.append(TEXT_54);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_55);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_56);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_57);
     if ("PASSWORD".equals(authMethod) || "PUBLIC_KEY_AND_PASSWORD".equals(authMethod)) { 
    stringBuffer.append(TEXT_58);
     passwordFieldName = "__PASSWORD__"; 
    stringBuffer.append(TEXT_59);
    if (ElementParameterParser.canEncrypt(node, passwordFieldName)) {
    stringBuffer.append(TEXT_60);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_39);
    stringBuffer.append(ElementParameterParser.getEncryptedValue(node, passwordFieldName));
    stringBuffer.append(TEXT_19);
    } else {
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_41);
    stringBuffer.append( ElementParameterParser.getValue(node, passwordFieldName));
    stringBuffer.append(TEXT_42);
    }
    stringBuffer.append(TEXT_62);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_63);
     } else { 
    stringBuffer.append(TEXT_64);
     } 
    stringBuffer.append(TEXT_65);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_66);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_67);
    
		passwordFieldName = "__PASSWORD__";
		
    stringBuffer.append(TEXT_68);
    stringBuffer.append(TEXT_69);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_70);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_71);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_72);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_73);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_74);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_75);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_76);
    if (("PUBLICKEY").equals(authMethod) || ("PUBLIC_KEY_AND_PASSWORD").equals(authMethod)){
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_77);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_78);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_79);
    stringBuffer.append(privateKey);
    stringBuffer.append(TEXT_80);
    }
    stringBuffer.append(TEXT_81);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_82);
    stringBuffer.append(privateKey );
    stringBuffer.append(TEXT_83);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_84);
    }
    stringBuffer.append(TEXT_85);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_86);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_87);
    stringBuffer.append(user);
    stringBuffer.append(TEXT_88);
    stringBuffer.append(host);
    stringBuffer.append(TEXT_88);
    stringBuffer.append(port);
    stringBuffer.append(TEXT_89);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_90);
    if (("PASSWORD").equals(authMethod)) {
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_77);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_91);
    }
    stringBuffer.append(TEXT_92);
    if (ElementParameterParser.canEncrypt(node, passwordFieldName)) {
    stringBuffer.append(TEXT_60);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_39);
    stringBuffer.append(ElementParameterParser.getEncryptedValue(node, passwordFieldName));
    stringBuffer.append(TEXT_19);
    } else {
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_41);
    stringBuffer.append( ElementParameterParser.getValue(node, passwordFieldName));
    stringBuffer.append(TEXT_42);
    }
    stringBuffer.append(TEXT_93);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_94);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_30);
    }
    stringBuffer.append(TEXT_85);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_95);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_30);
    if (!useProxy) {
    stringBuffer.append(TEXT_96);
    stringBuffer.append(TEXT_97);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_98);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_99);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_100);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_101);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_102);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_103);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_104);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_105);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_106);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_107);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_108);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_109);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_110);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_111);
    stringBuffer.append(port);
    stringBuffer.append(TEXT_112);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_113);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_114);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_109);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_115);
    }
    stringBuffer.append(TEXT_92);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_116);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_117);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_118);
    stringBuffer.append(user);
    stringBuffer.append(TEXT_80);
    }
    stringBuffer.append(TEXT_119);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_120);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_121);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_122);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_123);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_124);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_125);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_126);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_127);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_122);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_128);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_129);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_77);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_130);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_131);
    }
    stringBuffer.append(TEXT_132);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_133);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_134);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_135);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_136);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_137);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_138);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_139);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_140);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_141);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_142);
    }
    stringBuffer.append(TEXT_143);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_144);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_145);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_146);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_147);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_148);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_149);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_77);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_150);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    }
    stringBuffer.append(TEXT_151);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_152);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_153);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_154);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_155);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_156);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_157);
    if(use_encoding) {
    stringBuffer.append(TEXT_158);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_159);
    stringBuffer.append(encoding);
    stringBuffer.append(TEXT_160);
    }
    stringBuffer.append(TEXT_92);
    
	} else {
  
    stringBuffer.append(TEXT_161);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_162);
    stringBuffer.append(conn );
    stringBuffer.append(TEXT_163);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_164);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_165);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_166);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_167);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_168);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_169);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_170);
    }
    stringBuffer.append(TEXT_171);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_172);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_173);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_174);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_175);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_176);
    
	}
  
    stringBuffer.append(TEXT_177);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_41);
    stringBuffer.append(remotedir );
    stringBuffer.append(TEXT_178);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_179);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_180);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_181);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_182);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_183);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_184);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_185);
    
	if (dirFull) {

    stringBuffer.append(TEXT_186);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_185);
    
	}

    stringBuffer.append(TEXT_187);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_188);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_189);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_190);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_191);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_192);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_193);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_194);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_195);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_196);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_197);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_198);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_199);
    
				if (dirFull) {

    stringBuffer.append(TEXT_200);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_201);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_202);
    
				}

    stringBuffer.append(TEXT_203);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_204);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_205);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_206);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_207);
    }
    stringBuffer.append(TEXT_208);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_209);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_210);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_211);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_212);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_213);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_214);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_215);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_216);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_217);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_218);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_219);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_220);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_221);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_222);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_223);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_224);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_225);
    }
		if (dirFull) {

    stringBuffer.append(TEXT_226);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_227);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_214);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_228);
    
		} else {

    stringBuffer.append(TEXT_226);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_229);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    
		}

    stringBuffer.append(TEXT_230);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_231);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_232);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_149);
    
} else {
    if (ftps) { // *** ftps *** //

    stringBuffer.append(TEXT_233);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_234);
    
        if (("false").equals(useExistingConn)) {
            String keystoreFile = ElementParameterParser.getValue(node, "__KEYSTORE_FILE__");
            String securityMode = ElementParameterParser.getValue(node, "__SECURITY_MODE__");

    stringBuffer.append(TEXT_92);
    
    String portToConnect = ftpsPort;

    stringBuffer.append(TEXT_235);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_236);
    
			passwordFieldName = "__KEYSTORE_PASS__";
			if (ElementParameterParser.canEncrypt(node, passwordFieldName)) {

    stringBuffer.append(TEXT_237);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_39);
    stringBuffer.append(ElementParameterParser.getEncryptedValue(node, passwordFieldName));
    stringBuffer.append(TEXT_19);
    
			} else {

    stringBuffer.append(TEXT_238);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_41);
    stringBuffer.append( ElementParameterParser.getValue(node, passwordFieldName));
    stringBuffer.append(TEXT_42);
    
			}

    stringBuffer.append(TEXT_239);
    stringBuffer.append(keystoreFile);
    stringBuffer.append(TEXT_240);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_241);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_242);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_243);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_244);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_245);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_246);
    stringBuffer.append(TEXT_247);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    
			passwordFieldName = "__KEYSTORE_PASS__";
			if (ElementParameterParser.canEncrypt(node, passwordFieldName)) {

    stringBuffer.append(TEXT_249);
    stringBuffer.append(ElementParameterParser.getEncryptedValue(node, passwordFieldName));
    stringBuffer.append(TEXT_19);
    
			} else {

    stringBuffer.append(TEXT_250);
    stringBuffer.append( ElementParameterParser.getValue(node, passwordFieldName));
    stringBuffer.append(TEXT_251);
    
			}

    stringBuffer.append(TEXT_239);
    stringBuffer.append(keystoreFile);
    stringBuffer.append(TEXT_252);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_253);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_254);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_255);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_256);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_257);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_258);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_259);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_260);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_261);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_262);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_263);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_264);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_265);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_266);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_267);
    stringBuffer.append(TEXT_97);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_98);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_99);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_100);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_101);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_102);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_103);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_104);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_105);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_268);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_269);
    stringBuffer.append("IMPLICIT".equals(securityMode));
    stringBuffer.append(TEXT_270);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_271);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_272);
    stringBuffer.append("IMPLICIT".equals(securityMode));
    stringBuffer.append(TEXT_270);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_110);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_111);
    stringBuffer.append(ftpsPort);
    stringBuffer.append(TEXT_273);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_269);
    stringBuffer.append("IMPLICIT".equals(securityMode));
    stringBuffer.append(TEXT_270);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_274);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_272);
    stringBuffer.append("IMPLICIT".equals(securityMode));
    stringBuffer.append(TEXT_270);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_275);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_272);
    stringBuffer.append("IMPLICIT".equals(securityMode));
    stringBuffer.append(TEXT_270);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_276);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_77);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_277);
    stringBuffer.append(securityMode);
    stringBuffer.append(TEXT_278);
    }
    stringBuffer.append(TEXT_92);
    stringBuffer.append(TEXT_279);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_280);
    stringBuffer.append(encoding );
    stringBuffer.append(TEXT_281);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_77);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_282);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_118);
    stringBuffer.append(user );
    stringBuffer.append(TEXT_283);
    }
    stringBuffer.append(TEXT_284);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_285);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_286);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_287);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_288);
    stringBuffer.append(useStrictReplyParsing );
    stringBuffer.append(TEXT_289);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_290);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_291);
    stringBuffer.append(portToConnect);
    stringBuffer.append(TEXT_19);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_77);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_130);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_131);
    }
    
        passwordFieldName = cid.contains("Connection") ? "__PASS__" : "__PASSWORD__";

    stringBuffer.append(TEXT_92);
    if (ElementParameterParser.canEncrypt(node, passwordFieldName)) {
    stringBuffer.append(TEXT_60);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_39);
    stringBuffer.append(ElementParameterParser.getEncryptedValue(node, passwordFieldName));
    stringBuffer.append(TEXT_19);
    } else {
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_41);
    stringBuffer.append( ElementParameterParser.getValue(node, passwordFieldName));
    stringBuffer.append(TEXT_42);
    }
    stringBuffer.append(TEXT_292);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_293);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_294);
    stringBuffer.append(user );
    stringBuffer.append(TEXT_295);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_296);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_297);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_298);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_299);
    stringBuffer.append(useRemoteVerification );
    stringBuffer.append(TEXT_19);
    
        if (protectionBufferSize != null && !protectionBufferSize.isEmpty() ) {

    stringBuffer.append(TEXT_300);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_301);
    stringBuffer.append(protectionBufferSize );
    stringBuffer.append(TEXT_19);
    
        }

        if (protectionLevel != null && !protectionLevel.isEmpty()) {

    stringBuffer.append(TEXT_300);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_302);
    stringBuffer.append(protectionLevel );
    stringBuffer.append(TEXT_19);
    
        }

    stringBuffer.append(TEXT_303);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_304);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_305);
    }
    stringBuffer.append(TEXT_306);
    
    if ("PASSIVE".equals(connectMode)) {

    stringBuffer.append(TEXT_279);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_307);
    
        if (isLog4jEnabled) {

    stringBuffer.append(TEXT_308);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_309);
    
        }
    }

    
        } else {

    stringBuffer.append(TEXT_300);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_310);
    stringBuffer.append(conn );
    stringBuffer.append(TEXT_311);
    
        }
    } else { // *** ftp

    stringBuffer.append(TEXT_312);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_234);
    
        if (("true").equals(useExistingConn)) {
    stringBuffer.append(TEXT_300);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_313);
    stringBuffer.append(conn );
    stringBuffer.append(TEXT_311);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_314);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_315);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_316);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_317);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_318);
    }
    
        } else {
            passwordFieldName = "__PASSWORD__";

    stringBuffer.append(TEXT_92);
    
    String portToConnect = port;

    stringBuffer.append(TEXT_319);
    stringBuffer.append(TEXT_97);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_98);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_99);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_100);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_101);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_102);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_103);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_104);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_320);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_321);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_322);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_323);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_111);
    stringBuffer.append(ftpsPort);
    stringBuffer.append(TEXT_324);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_325);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_326);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_327);
    stringBuffer.append(TEXT_279);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_280);
    stringBuffer.append(encoding );
    stringBuffer.append(TEXT_281);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_77);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_282);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_118);
    stringBuffer.append(user );
    stringBuffer.append(TEXT_283);
    }
    stringBuffer.append(TEXT_284);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_285);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_286);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_287);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_288);
    stringBuffer.append(useStrictReplyParsing );
    stringBuffer.append(TEXT_289);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_290);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_291);
    stringBuffer.append(portToConnect);
    stringBuffer.append(TEXT_19);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_77);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_130);
    stringBuffer.append(host );
    stringBuffer.append(TEXT_131);
    }
    
        passwordFieldName = cid.contains("Connection") ? "__PASS__" : "__PASSWORD__";

    stringBuffer.append(TEXT_92);
    if (ElementParameterParser.canEncrypt(node, passwordFieldName)) {
    stringBuffer.append(TEXT_60);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_39);
    stringBuffer.append(ElementParameterParser.getEncryptedValue(node, passwordFieldName));
    stringBuffer.append(TEXT_19);
    } else {
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_41);
    stringBuffer.append( ElementParameterParser.getValue(node, passwordFieldName));
    stringBuffer.append(TEXT_42);
    }
    stringBuffer.append(TEXT_292);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_293);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_294);
    stringBuffer.append(user );
    stringBuffer.append(TEXT_295);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_296);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_297);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_328);
    if(isLog4jEnabled){
    stringBuffer.append(TEXT_304);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_305);
    }
    stringBuffer.append(TEXT_306);
    
    if ("PASSIVE".equals(connectMode)) {

    stringBuffer.append(TEXT_279);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_307);
    
        if (isLog4jEnabled) {

    stringBuffer.append(TEXT_308);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_309);
    
        }
    }

    
        }
    } //common code for ftp and ftps:

    stringBuffer.append(TEXT_329);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_330);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_331);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_293);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_332);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_333);
    /*read files*/ 
    stringBuffer.append(TEXT_334);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_335);
    stringBuffer.append(remotedir);
    stringBuffer.append(TEXT_336);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_293);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_337);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_338);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_339);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_340);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_293);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_341);
    if(!dirFull){
    stringBuffer.append(TEXT_342);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_293);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_343);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_344);
    }
    stringBuffer.append(TEXT_345);
    
    if ("true".equals(useExistingConn) && !moveToCurrentDir) {

    /*return to previous dir */
    stringBuffer.append(TEXT_346);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_347);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_19);
    
    }

    /*prepare masks*/ 
    stringBuffer.append(TEXT_348);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_188);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_349);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_190);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_350);
    if(!dirFull){
    stringBuffer.append(TEXT_351);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_352);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_353);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_354);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_355);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_356);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_357);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_358);
    }else{
    stringBuffer.append(TEXT_359);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_360);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_361);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_362);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_363);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_364);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_365);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_366);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_357);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_367);
    }
    stringBuffer.append(TEXT_368);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_216);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_369);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_218);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_370);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_371);
    if(!dirFull){
    stringBuffer.append(TEXT_372);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_373);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_374);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_362);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_375);
    }else{
    stringBuffer.append(TEXT_376);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_377);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_374);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_378);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_362);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_379);
    
}

        if(isLog4jEnabled) {

    stringBuffer.append(TEXT_308);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_224);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_380);
    
        }

    stringBuffer.append(TEXT_381);
    /*set to globalMap*/ 
    stringBuffer.append(TEXT_382);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_229);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_160);
    if(!dirFull){
    stringBuffer.append(TEXT_382);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_231);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_383);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_281);
    }else{
    stringBuffer.append(TEXT_382);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_231);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_384);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_385);
    }
    stringBuffer.append(TEXT_386);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_387);
    
} //end common code part

    return stringBuffer.toString();
  }
}
